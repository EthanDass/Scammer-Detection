from cerberus import Validator

Photo = {
  'type': 'dict',
  'schema': {
    'isR': {'type': 'boolean', 'nullable': True},
    'rScore': {'type': 'float', 'nullable': True},
    'isAdultContent': {'type': 'boolean', 'nullable': True},
    'adultScore': {'type': 'float', 'nullable': True},
    'faces': {
      'type': 'list',
      'schema': {
        'type': 'dict',
        'schema': {
          'age': {'type': 'integer', 'nullable': True},
          'gender': {'type': 'string', 'nullable': True}
        }
      },
      'nullable': True
    },

  }
}

Profile = {
  'type': 'dict',
  'schema': {
    'id': {'type':'string', 'nullable': True}
  }
}

Tagline = {
  'type': 'dict',
  'schema': {
    'created_at': {'type':'string', 'nullable': True},
    'deleted_at': {'type':'string', 'nullable': True}
  }
}

User = {
  'type': 'dict',
  'schema': {
    'fb_id': {'type':'string', 'nullable': True},
    'email': {'type':'string', 'nullable': True},
    'hometown': {'type':'string', 'nullable': True},
    'school': {'type':'string', 'nullable': True},
    'position': {'type':'string', 'nullable': True},
    'mission_location': {'type':'string', 'nullable': True},
    'user_id': {'type':'string', 'nullable': True},
    'age': {'type':'integer', 'nullable': True},
    'gender': {'type':'string', 'nullable': True},
    'dating_interest': {'type':'integer', 'nullable': True},
    'pref_age_low': {'type':'float', 'nullable': True},
    'pref_age_high': {'type':'float', 'nullable': True},
    'pref_search_radius': {'type':'integer', 'nullable': True},
    'country_code': {'type':'string', 'nullable': True},
  }
}

schema = {
  'user': User,
  'taglines': {
    'type': 'list',
    'schema': Tagline
  },
  'profile': {
    'type': 'list',
    'schema': Profile
  },
  'photos': {
    'type': 'list',
    'schema': Photo
  }
}

class Schema:
  def __init__(self):
    self.v = Validator(schema)

  def validate(self, body):
    return self.v.validate(body)