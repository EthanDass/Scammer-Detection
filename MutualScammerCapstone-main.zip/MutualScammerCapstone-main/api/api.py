import json
import statistics
import pandas as pd
from flask import Flask, request, jsonify
from model import Model
from schema import Schema

app = Flask(__name__)

model = Model()
schema = Schema()

## This determines how probable a user needs to be to be classified as a scammer
scammer_score_cutoff = 0.7

###### HELPER FUNCTIONS #######
# Returns value of key if in object, otherwise default value
def default(obj, key, def_val):
  return obj[key] if key in obj else def_val

# Returns bool of whether users age is within their preferred dating range
def get_in_age_range(user):
  l = user['pref_age_low']
  h = user['pref_age_high']
  age = user['age']

  if l == 0 and h == 0:
    return False

  if l == 0 and age < h:
    return True

  if h == 0 and age > l:
    return True

  if age > l and age < h:
    return True

  return False

# Return the difference between lower and higher age preference
def get_age_range_size(user):
  l = user['pref_age_low']
  h = user['pref_age_high']

  if l == 0 or h == 0:
    return 0
  
  return h-l

# Safely checks if ig is connected
def get_is_ig_connected(user):
  if not 'is_ig_connected' in user:
    return 0
  
  return bool(user['is_ig_connected'])

# Safely gets the age of a face
def get_age_from_face(row):
  faces = row['faces']

  if faces is None or isinstance(faces, float) or len(faces) == 0:
    return None

  return faces[0]['age']


###### PARSING FUNCTIONS ######
# These functions convert raw data from the request to what the model can use

# Parses the user data from the request and formats it for the model
def parse_user_data(user):
  # get boolean values and default values
  return_data = {
    # Boolean values for whether field is present
    'fb_id': 'fb_id' in user,
    'email': 'email' in user,
    'hometown': 'hometown' in user,
    'school': 'school' in user,
    'position': 'position' in user,
    'mission_location': 'mission_location' in user,
    # Set defaults for numeric values
    'age': default(user, 'age', 0),
    'gender': default(user, 'gender', False),
    'dating_interest': default(user, 'dating_interest', 0),
    'pref_age_low': default(user, 'pref_age_low', 0),
    'pref_age_high': default(user, 'pref_age_high', 0),
    'pref_search_radius': default(user, 'pref_search_radius', 0),
    # Get computed values
    'in_age_range': get_in_age_range(user),
    'is_ig_connected': get_is_ig_connected(user),
    'age_range_size': get_age_range_size(user),
  }

  # convert gender to number
  return_data['gender'] = return_data['gender'] == 'male'

  return return_data

# Parses the tagline data from the request and formats it for the model
# The model needs a count of active and deleted tags for the user
def parse_tagline_data(taglines):
  active_tag_count = sum(1 for i in taglines if bool(i['deleted_at']))
  deleted_tag_count = len(taglines) - active_tag_count

  return {
    'active_tag_count': active_tag_count,
    'deleted_tag_count': deleted_tag_count
  }

# Parses the photo data for the model
def parse_photo_data(photos):
  return {
    'photo_count': len(photos),
    'photo_age': sum(get_age_from_face(p) for p in photos) / len(photos),
    'adultScore': max(p['adultScore'] for p in photos),
    'rScore': max(p['rScore'] for p in photos),
    'photo_gender': statistics.mode(p['faces'][0]['gender'] for p in photos) == 'Male'
  }

# Parses the profile data for the model
# We only use the count of profiles
def parse_profile_data(profiles):
  return {
    'profile_count': len(profiles)
  }

###### API ROUTES ######
@app.route('/', methods=['POST'])
def score_user():
  body = json.loads(request.data)

  # Validate request
  if not schema.validate(body):
    return jsonify({
      'Error': 'malformed request',
      'error_tree': schema.v.errors
    })

  user_data = parse_user_data(body['user'])
  tagline_data = parse_tagline_data(body['taglines'])
  photo_data = parse_photo_data(body['photos'])
  profile_data = parse_profile_data(body['profile'])

  data = dict(user_data)
  data.update(tagline_data)
  data.update(photo_data)
  data.update(profile_data)

  # Compute values between datasets
  data['gender_diff'] = data['gender'] == data['photo_gender']
  data['age_diff'] = data['age'] - data['photo_age']

  # Returns a list of probability user is a scammer and probability user is not a scammer
  # Just return the probability user is a scammer
  score = model.predict(pd.DataFrame.from_records([data]))[0]

  return jsonify({
    'score': round(score, 5),
    'isScammer': bool(score >= scammer_score_cutoff)
  })

###### START THE API ######
app.run(debug=True)