import pickle


rf_file = 'finalized_rfmodel.sav'
class Model:
  def __init__(self):
    self.random_forest = pickle.load(open(rf_file, 'rb'))

  def predict(self, user):
    # Predict will return probabilites for all items passed to it
    # We're giving it one at a time so we just need to return the first result
    return self.random_forest.predict_proba(user)[0]